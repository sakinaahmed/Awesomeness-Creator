=== Awesomeplugin===
Contributors: Sakina
Tags: Sakina, calucalte to lift weight, weight
Requires at least: 4.6
Tested up to: 5.4
Stable tag: 1.0
License: GPLv2 or later

Awesomeplugin takes your age and weight as a input. This plugin give you helth advice as per your age and weight.Rightnow no need of database for this plugin. 

== Description ==

Awesomeplugin takes your age and weight as a input. This plugin give you helth advice as per your age and weight.Rightnow no need of database for this plugin. 

Major features in Awesomeplugin include:

* Automatically caluclat weight that you can lift.
* Validation is done for each input feild.


== Installation ==

Upload the Awesomeplugin plugin to your plugin folder of site, activate it on admin plugin page , and then at the end of each and every page you can access this plugin.

1, 2, 3: You're done!

== Changelog ==

= 1.0 =
*Release Date - 19 Jan 2021*

*In Future We will store data in database and also give more functionality related to helth*